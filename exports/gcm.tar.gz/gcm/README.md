# GCM — Game Center Manager

Standalone React + Vite + Tailwind v4 + i18next (FR/EN) app.

## Setup in a fresh Replit project

This package was extracted from a pnpm monorepo. To use it as a standalone app:

1. Open the new Replit project, drop these files at the project root (so `package.json` sits next to `index.html`).
2. Edit `package.json`:
   - Change `"name"` to `"gcm"` (remove `@workspace/` prefix).
   - Replace any `"catalog:"` versions with real semver (see "Versions" below).
3. Remove `vite.config.ts` references to `@workspace/*` if any, and ensure `base` matches how you serve it (use `"/"` for root).
4. Install: `npm install` (or `pnpm install`).
5. Run: `npm run dev`.

## Versions (in case `catalog:` is unresolved)

- react / react-dom: `^19.1.0`
- vite: `^7.3.0`
- @vitejs/plugin-react: `^4.3.0`
- typescript: `^5.6.0`
- tailwindcss: `^4.0.0`
- @tailwindcss/vite: `^4.0.0`
- wouter: `^3.3.0`
- lucide-react: `^0.460.0`
- i18next: `^23.15.0`
- react-i18next: `^15.1.0`
- i18next-browser-languagedetector: `^8.0.0`

## Routes

- `/` — Dashboard (revenue hero, KPIs, hourly chart, live ticker, activity feed, top games + customers).
- `/postes` — Stations bento grid + session detail modal.
- Anything else — localized "Coming soon" placeholder.

## Theme & i18n

- Light theme is the default. Toggle dark with the sun/moon button in the topbar (persisted to `localStorage` under `gcm-theme`).
- French is the default language. EN/FR switch in the topbar (persisted to `localStorage` under `gcm-lang`).
- All strings live in `src/locales/{fr,en}.json`.
